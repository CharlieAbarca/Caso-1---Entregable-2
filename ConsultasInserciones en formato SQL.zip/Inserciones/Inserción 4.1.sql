-- =========================================RESPUESTA 4.1 (INSERCIONES)=============================

USE `paymentassistant`;

-- Ubicación: País, Estado, Ciudad y Dirección
INSERT INTO `pay_country` (`country_id`, `name`, `currency`, `currencysymbol`, `language`)
VALUES (1, 'Costa Rica', 'CRC', '₡', 'es');

INSERT INTO `pay_state` (`state_id`, `name`, `country_id`)
VALUES (1, 'San José', 1);

INSERT INTO `user_cities` (`city_id`, `name`, `state_id`)
VALUES (1, 'San José', 1);

INSERT INTO `pay_address` (`addressid`, `line1`, `line2`, `zipcode`, `geoposition`, `city_id`)
VALUES (1, 'Avenida Central 123', NULL, '10101', ST_GeomFromText('POINT(0 0)'), 1);

-- Método de pago
INSERT INTO `pay_method` (`method_id`, `name`, `apiURL`, `secret_key`, `key`, `logoIconURL`, `enabled`, `config`)
VALUES (1, 'Tarjeta de Crédito', 'https://api.tdc.example.com',
        'abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890',
        '1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef',
        'https://img.tdc.example.com/logo.png', b'1', '{"param": "valor"}');


-- FUNCIONES PARA INSERTAR AL USER
DROP PROCEDURE IF EXISTS sp_fill_pay_user;
DELIMITER //
CREATE PROCEDURE sp_fill_pay_user()
BEGIN
  DECLARE i INT DEFAULT 1;
  WHILE i <= 20 DO
    INSERT INTO `pay_user` 
      (`name`, `last_name`, `phone`, `birth`, `password`, `delete`, `last_update`, `active`, `role`, `email`)
    VALUES (
      CONCAT('Nombre', i),
      CONCAT('Apellido', i),
      LPAD(i, 8, '0'),
      DATE_SUB('1990-01-01', INTERVAL i YEAR),
      UNHEX(SHA2(CONCAT('pass', i), 256)),
      b'0',
      NOW(),
      b'1',  -- Solo usuarios activos
      1,
      CONCAT('user', i, '@example.com')
    );
    SET i = i + 1;
  END WHILE;
END //
DELIMITER ;
-- LLAMADA A LA FUNCIÓN
CALL sp_fill_pay_user();

-- LLENADO DE TABLA DE METODOS
DROP PROCEDURE IF EXISTS sp_fill_pay_available_method;
DELIMITER //
CREATE PROCEDURE sp_fill_pay_available_method()
BEGIN
  DECLARE i INT DEFAULT 1;
  WHILE i <= 20 DO
    INSERT INTO `pay_available_method`
      (`available_method`, `mask_account`, `token`, `exptokendate`, `name`, `user_id`, `method_id`)
    VALUES (
      i, 
      CONCAT('****', LPAD(1000 + i, 4, '0')),
      UNHEX(SHA2(CONCAT('token', i), 256)),
      '2025-12-31',
      CONCAT('Cuenta Usuario ', i),
      i,  -- Se asume que el usuario con user_id = i ya existe
      1
    );
    SET i = i + 1;
  END WHILE;
END //
DELIMITER ;

-- LLAMADA A LA FUNCIÓN
CALL sp_fill_pay_available_method();

-- LLENAR TABLA DE PAGOS
DROP PROCEDURE IF EXISTS sp_fill_payments;
DELIMITER //
CREATE PROCEDURE sp_fill_payments()
BEGIN
  DECLARE uid INT DEFAULT 1;
  DECLARE random_price DECIMAL(10,2);
  DECLARE random_date DATE;
  WHILE uid <= 20 DO
    SET random_price = FLOOR(18000 + (RAND() * (33000 - 18000)));
    SET random_date = DATE_ADD('2024-01-01', INTERVAL FLOOR(RAND() * DATEDIFF(CURDATE(), '2024-01-01')) DAY);
    INSERT INTO `payments`
      (`payments_id`, `user_id`, `available_method`, `price`, `current_price`, `currency`, `auth`, `changeToken`, `description`, `error`, `date`, `result`, `checksum`, `schedule_id`)
    VALUES (
      uid,         
      uid,
      uid,         
      random_price,
      random_price,
      'CRC',
      CONCAT('auth', uid),
      UNHEX(SHA2(CONCAT('chg', uid), 256)),
      'Suscripción 2024',
      b'0',
      random_date,
      'SUCCESS',
      UNHEX(SHA2(CONCAT('chk', uid), 256)),
      NULL
    );
    SET uid = uid + 1;
  END WHILE;
END //
DELIMITER ;

-- LLAMADA A LA FUNCIÓN
CALL sp_fill_payments();